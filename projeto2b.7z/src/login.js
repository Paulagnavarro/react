import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';

const Login = () => {
    const handleSubmit = (event) => {
        event.preventDefault();
        const nome = event.target.formNome.value;
        const email = event.target.formEmail.value;
        const senha = event.target.formSenha.value;
        console.log('Nome:', nome, 'Email:', email, 'Senha:', senha);
    };

    return (
        <div>
            {/* Navbar */}
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container">
                    <a className="navbar-brand" href="#">Minha App</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <Link className="nav-link" to="/criar-conta">Criar conta</Link>
                            </li>
                            <li className="nav-item">
                                <span className="nav-link active">Login</span>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            {/* Formulário de Login */}
            <div className="container mt-5">
                <h2>Login</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="formNome">Nome</label>
                        <input type="text" className="form-control" id="formNome" placeholder="Digite seu nome" required />
                    </div>

                    <div className="form-group">
                        <label htmlFor="formEmail">Email</label>
                        <input type="email" className="form-control" id="formEmail" placeholder="Digite seu email" required />
                    </div>

                    <div className="form-group">
                        <label htmlFor="formSenha">Senha</label>
                        <input type="password" className="form-control" id="formSenha" placeholder="Digite sua senha" required />
                    </div>

                    <button type="submit" className="btn btn-primary">Cadastrar</button>
                </form>
            </div>
        </div>
    );
};

export default Login;
