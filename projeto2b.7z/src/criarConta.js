import React from 'react';

const CriarConta = () => {
    return (
        <div className="container mt-5">
            <h2>Criar Conta</h2>
            {/* Aqui você pode adicionar o formulário de criar conta */}
        </div>
    );
};

export default CriarConta;
