import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './login';
import CriarConta from './criarConta';

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/criar-conta" element={<CriarConta />} />
            </Routes>
        </Router>
    );
};

export default App;
